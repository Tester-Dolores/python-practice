### 0.9.2-pre
*

### 0.9.1
* Add file_path arg to webconsole#install_bundle to allow custom bundle file location
* Add response code 201 handling as webconsole#install_bundle success 
* Add response code 201 handling as webconsole#start_bundle success 
* Add response code 201 handling as pakagemanagersync#* success

### 0.9.0
* Initial version
